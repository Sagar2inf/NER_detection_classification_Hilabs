To set up the project environment, ensure that all the required Python packages are installed. This can be done using the requirements.txt file, which lists all the dependencies

We have uploaded our trained model on hugging face, you can access this model through following links.
1) https://huggingface.co/NitinGCJ/ai-quest-p1 (peft adopter for Sdoh)
2) https://huggingface.co/NitinGCJ/ai-quest-p2 (peft adopter for Clinical entity)

We have submitted the zip folder which consists required files.

The name of dataset used for training adopter have following names in submitted zip folder:
1) sdoh adopter: "output_sdoh.csv"
2) Clinical entity: "output_clinical.csv"
3) Attribute NER: "output_attribute.csv"

and here is the GitHub repo link:
https://github.com/Sagar2inf/NER_detection_classification_Hilabs